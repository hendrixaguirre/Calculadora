# Borrador académico — AXION Programa 2

Este archivo prepara el contenido del informe, pero **no sustituye el PDF final**.
Los datos marcados como pendientes no deben inventarse.

## Portada

- Universidad: UAM
- Facultad: FIA
- Asignatura: Álgebra Lineal MTM0120
- Actividad: Programa 2 — Reducción Gauss-Jordan
- Docente: **[PENDIENTE]**
- Integrantes: **[PENDIENTE]**
- Carrera: **[PENDIENTE]**
- Grupo: **[PENDIENTE]**
- Fecha: **[PENDIENTE DE CONFIRMACIÓN]**

## Explicación del algoritmo

AXION representa la matriz aumentada mediante listas anidadas y convierte cada
escalar a `Fraction`. El algoritmo recorre las columnas de izquierda a derecha.
Para cada columna busca una fila con un valor no nulo; si es necesario,
intercambia filas. Después multiplica la fila pivote por el inverso del pivote
para convertirlo en uno. Finalmente aplica

`F_destino ← F_destino − (c/p)F_pivote`

a todas las demás filas, incluida siempre la columna `b`. Si una columna de `A`
no posee candidato, se registra como columna sin pivote. Si aparece un pivote en
`b`, este representa una contradicción y no una variable adicional.

La RREF permite identificar columnas pivote, variables básicas y variables
libres. Los rangos clasifican el sistema: rangos distintos significan
inconsistencia; rangos iguales al número de variables significan solución única;
y rangos iguales menores que dicho número producen infinitas soluciones.

## Capturas requeridas

- **[PENDIENTE]** Solución única: Caso A del encargo.
- **[PENDIENTE]** Infinitas soluciones: Caso B del encargo.
- **[PENDIENTE]** Inconsistencia y pivote en `b`: Caso C del encargo.

Las capturas deben provenir de la ejecución final y mostrar entrada, RREF,
pivotes, interpretación y verificación.

## Borrador de reflexión sobre IA

Se utilizó asistencia de inteligencia artificial para revisar requisitos,
proponer una organización modular, detectar casos límite, implementar partes de
la interfaz y ampliar las pruebas. La salida no se aceptó como autoridad
matemática: se contrastó con casos conocidos, propiedades de la RREF y pruebas
automáticas. El equipo debe revisar este texto y describir qué partes modificó,
qué decisiones comprendió y cómo verificó personalmente el algoritmo antes de
la defensa.

## Preguntas de práctica para la defensa

1. ¿Por qué una operación elemental conserva las soluciones?
2. ¿Qué diferencia existe entre forma escalonada y RREF?
3. ¿Por qué un pivote en `b` demuestra inconsistencia?
4. ¿Cómo se obtiene el rango a partir de una matriz reducida?
5. ¿Cómo se construyen los vectores de dirección de una solución paramétrica?
6. ¿Por qué `Fraction` no reemplaza el algoritmo de Gauss-Jordan?
7. ¿Qué datos contiene un evento de operación y cómo reproduce el paso?
8. ¿Por qué el formato decimal no debe modificar la clasificación?

## Nombres finales pendientes

- ZIP: `Programa 2_Grupo x_Apellido1_Apellido2.zip`
- PDF: `Informe_Programa 2_Grupo x.pdf`

No deben generarse con datos ficticios.
