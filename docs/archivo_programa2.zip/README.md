# AXION — Programa 2

Calculadora educativa sin conexión para reducir matrices aumentadas `[A|b]` a
forma escalonada reducida por filas (RREF) mediante Gauss-Jordan. El algoritmo
está implementado manualmente con listas, ciclos y operaciones elementales; no
usa NumPy, SymPy ni solucionadores externos.

## Requisitos comprobados

- Python 3.10 o posterior recomendado.
- Tcl/Tk 8.6 y el módulo estándar `tkinter`.
- No requiere `pip` ni conexión a Internet.

En el entorno de desarrollo se comprobó Python 3.14.6, Tcl/Tk 8.6 y escala Tk
1.3346. El punto de entrada detecta y explica la ausencia de una interfaz Tk
operativa.

## Ejecutar Programa 2

```powershell
python "Programa 2_Grupox.py"
```

La `x` es un marcador: reemplázala únicamente cuando se conozca el número real
del grupo. Los módulos auxiliares deben permanecer junto al lanzador.

## Recorrido

1. **Definir sistema:** elige entre 1 y 8 ecuaciones y variables; introduce
   enteros, decimales o fracciones.
2. **Resolver paso a paso:** el modo Guiado comienza en la matriz inicial y
   permite reconstruir cada intercambio, normalización y reemplazo.
3. **Interpretar y verificar:** muestra RREF, rangos, pivotes de `A` y `[A|b]`,
   variables, solución y comprobación exacta.

Los decimales se convierten directamente a racionales. El formato Decimal es
solo una aproximación visual marcada con `≈`.

## Límites de entrada

- Máximo 8 ecuaciones y 8 variables: una aumentada de hasta 8×9.
- Máximo 4096 caracteres por pegado.
- Máximo 64 caracteres y 48 dígitos por escalar.
- Exponentes entre −100 y 100, sujetos también al límite de magnitud.
- Formatos: `-3`, `0.125`, `1,25`, `-7/9` o `1e-3`.
- No se admiten expresiones, símbolos, infinitos, `NaN` ni denominador cero.

Cuando una coma aislada puede ser decimal o separador, AXION solicita una
decisión antes de modificar el editor. El pegado se previsualiza y se aplica de
forma atómica.

## Historial y reportes

- Historial JSON validado de hasta 50 ejercicios.
- Escritura atómica y conservación en memoria si el disco falla.
- Los racionales se guardan como texto exacto, nunca con `pickle`.
- Reportes TXT y HTML autocontenido.
- **Abrir reporte para imprimir** utiliza el navegador y su diálogo de impresión;
  no afirma haber generado un PDF automáticamente.

## Atajos

- `Ctrl+Enter`: resolver.
- `Ctrl+Z`: deshacer edición.
- `Ctrl+C` / `Ctrl+V`: copiar o pegar texto.
- `F1`: ayuda.
- `Escape`: cancelar una edición o cerrar diálogos compatibles.

## Pruebas

```powershell
python -m unittest -v
```

La suite cubre resultados conocidos, propiedades de RREF, pivote en `b`,
matrices rectangulares, 1×1 y 8×9, fracciones/decimales, eventos reconstruibles,
entrada inmutable, estados de interfaz, pegado atómico, historial, permisos y
reportes HTML.

## Alcance y pendientes académicos

AXION resuelve sistemas lineales numéricos. No admite parámetros simbólicos en
la entrada, números complejos, problemas no lineales, mínimos cuadrados,
determinantes, inversas ni autovalores.

El paquete académico y el PDF continúan pendientes hasta conocer grupo,
integrantes, apellidos, docente y carrera, y hasta capturar evidencia final
revisada. Consulta `DOCUMENTACION_PROGRAMA2.md` y `QA_PROGRAMA2.md` para el
estado de validación, las mediciones y las pruebas manuales aún pendientes.
