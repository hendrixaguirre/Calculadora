"""Punto de entrada académico de AXION — Programa 2.
"""

from __future__ import annotations

import sys


def tkinter_disponible() -> tuple[bool, str]:
    """Comprueba que importar Tkinter y crear una raíz Tcl/Tk sea posible."""
    try:
        import tkinter as tk
        raiz = tk.Tk()
        raiz.withdraw()
        version = f"Tk {tk.TkVersion} / Tcl {tk.TclVersion}"
        raiz.destroy()
        return True, version
    except Exception as error:
        return False, str(error)


def principal() -> int:
    disponible, detalle = tkinter_disponible()
    if not disponible:
        print(
            "AXION no pudo iniciar la interfaz gráfica. Verifica que tu instalación "
            f"de Python incluya Tcl/Tk. Detalle: {detalle}", file=sys.stderr,
        )
        return 1
    from axion_ui import lanzar_aplicacion
    lanzar_aplicacion()
    return 0


if __name__ == "__main__":
    raise SystemExit(principal())
