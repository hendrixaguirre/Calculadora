# AXION — Registro de calidad de Programa 2

Fecha de revisión: 7 de septiembre de 2026.

## Entorno comprobado

- Windows 11, compilación reportada por Python `10.0.26200`.
- Python 3.14.6.
- Tcl/Tk 8.6.15 disponible y operativo.
- Escala real informada por Tk: `1.334646962233169`.
- Pantalla informada por Tk: 1536 × 864.
- Procesador: Intel Core i5-13420H.
- La aplicación utiliza únicamente biblioteca estándar de Python. No requiere
  NumPy, SciPy, SymPy, Pillow, ReportLab ni conexión a Internet.

## Línea base y regresión

Antes del rediseño se ejecutó la suite existente: 44 pruebas aprobadas. Después
de implementar Programa 2 se ejecutaron realmente estos comandos:

```text
python -m py_compile axion_core.py axion_storage.py axion_ui.py "Programa 2_Grupox.py" test_programa.py
python -m unittest -q
git diff --check
```

Resultado final: 80 pruebas ejecutadas, 80 aprobadas, sin advertencias de Tcl/Tk
y sin errores de compilación ni de espacios del diff.

La suite cubre resultados conocidos, RREF e idempotencia, reproducción de
eventos, independencia de instantáneas, matrices rectangulares, 1×1 y 8×9,
lectura exacta y entradas inválidas, pegado atómico, deshacer, estado de
resultado anterior, navegación, historial, corrupción/permisos y reportes TXT y
HTML reales en directorios temporales. También cubre recuperación del resultado
vigente al deshacer, navegación del cursor dentro de las celdas, pegados con
celdas vacías, fallos inesperados del motor, desplazamiento anidado y estados
sin efecto.

Fuera de la suite se contrastaron 1,152 sistemas enteros y 640 sistemas
racionales aleatorios contra una reducción de referencia independiente. Las
RREF, rangos y clasificaciones coincidieron en todos los casos.

## Casos de referencia comprobados

1. Solución única: la RREF obtenida fue la identidad aumentada por
   `(2, 3, -1)`, con rangos 3 y 3, pivotes 1, 2 y 3 y diferencia exacta cero en
   las tres ecuaciones.
2. Infinitas soluciones: se obtuvo `[1, 2, -1 | 3]` y una fila nula, rango 1,
   básica `x1`, libres `x2` y `x3`, particular `(3,0,0)` y direcciones
   `(-2,1,0)` y `(1,0,1)`. Se comprobaron exactamente `A·xp=b` y `A·vi=0`.
3. Inconsistente: se obtuvo la RREF completa `[1,1|0]`, `[0,0|1]`; los
   pivotes de A y de la aumentada quedaron separados, y `b` se identifica como
   contradicción, no como una variable.

## Rendimiento medido

Sobre el caso de referencia de solución única:

- cálculo del motor, promedio de 100 ejecuciones: 0.570 ms;
- construcción de la vista de resultado, promedio de 3 ejecuciones: 154.629 ms.

Estas cifras describen solo este equipo y este caso; no son una garantía para
otras matrices o computadoras.

## Revisión visual y adaptable

Durante la implementación se abrieron y examinaron en la ventana real las
vistas de edición, procedimiento y resultado para solución única e
inconsistencia, pasos de pivote/eliminación, matriz 8×9 y ventana estrecha. La
inspección de 8×9 detectó que el comparador dependía solo del ancho de ventana;
se corrigió para estimar también las columnas y la longitud de las fracciones.

Después de la corrección final, una comprobación sobre el árbol real de Tk a
1280 × 800 confirmó que la matriz 8×9 se distribuye como `Antes ↓ Después`
(filas 0 y 2 de la misma columna), con ancho matemático estimado de 726 px por
matriz y desplazamiento local. A 850 × 700 se confirmaron etiquetas abreviadas
para las tres etapas y ocultamiento de información secundaria del encabezado.

La auditoría final recorrió las cuatro pestañas y las tres clasificaciones a
820×620, 850×700, 1024×768, 1280×720, 1366×768, 1536×864 y 1920×1080
(limitada a 1920×1061 por el área útil). No se detectaron controles fuera del
área cliente ni contenidos horizontales sin una vía de desplazamiento. También
se comprobó el cambio reversible `Antes ↓ Después` / `Antes → Después` al
redimensionar, conservando el paso activo.

Contrastes medidos sobre superficie blanca: tinta 16.27:1, texto secundario
4.97:1, azul cobalto 6.70:1 y cobre 7.31:1.

Limitación honesta: el controlador nativo informó que su servicio de Windows no
está configurado; por ello la distribución final se verificó en widgets reales
de Tk, pero falta guardar una captura visual nueva de esa versión exacta. Una
prueba geométrica no sustituye por sí sola la inspección humana de capturas.

## Teclado, escalado y lector de pantalla

- Se implementaron `Ctrl+Enter`, `Ctrl+Z`, `F1`, `Alt+Izquierda`,
  `Alt+Derecha` y `Ctrl+S`, además de controles estándar con texto.
- Se probaron programáticamente navegación de pasos, cursor dentro de celdas,
  deshacer, pegado y enrutamiento de la rueda. Completar el recorrido entero
  exclusivamente con teclado continúa como prueba manual pendiente.
- El entorno real disponible corresponde a escala Tk aproximada de 125 %.
- Quedan pendientes pruebas físicas independientes con escalado de Windows al
  100 %, 150 % y 200 %, y capturas en 1024×768, 1280×720, 1366×768 y
  1920×1080. Cambiar `tk scaling` artificialmente no se cuenta como aprobación.
- No hubo Narrador ni NVDA disponible para una prueba completa. No se declara
  conformidad con lector de pantalla ni WCAG; los contrastes son objetivos de
  diseño medidos, no una certificación.

## Estado del paquete académico

La aplicación, pruebas, historial y reportes TXT/HTML están implementados. El
PDF académico, sus capturas finales y el ZIP oficial siguen pendientes porque
faltan grupo, docente, carrera, integrantes y apellidos. No deben inventarse.
Los nombres previstos son `Informe_Programa 2_Grupo x.pdf` y
`Programa 2_Grupo x_Apellido1_Apellido2.zip`.
