"""Punto de entrada de AXION.

La interfaz vive en ``axion_ui.py`` y el motor matemático exacto en
``axion_core.py``. El modo consola se conserva para la entrega académica.
"""

from __future__ import annotations

import sys

from axion_core import (
    construir_reporte,
    numero_compacto,
    copiar_matriz,
    texto_ecuacion,
    texto_ecuaciones,
    matriz_exacta,
    formatear_numero,
    texto_matriz,
    lineas_parametricas,
    resolver_sistema,
    a_fraccion,
)
from axion_ui import AplicacionAxion, lanzar_aplicacion


def leer_entero_positivo(mensaje):
    while True:
        try:
            valor = int(input(mensaje))
            if valor > 0:
                return valor
            print("El valor debe ser mayor que cero.")
        except ValueError:
            print("Entrada inválida. Escribe un número entero.")


def leer_numero(mensaje):
    while True:
        try:
            return a_fraccion(input(mensaje))
        except ZeroDivisionError:
            print("El denominador no puede ser cero.")
        except ValueError:
            print("Utiliza un entero, decimal o una fracción como 3/4.")


def solicitar_sistema():
    print("\nDEFINIR SISTEMA Ax = b")
    ecuaciones = leer_entero_positivo("Número de ecuaciones: ")
    variables = leer_entero_positivo("Número de variables: ")
    matriz = []
    for fila in range(ecuaciones):
        print(f"\nEcuación {fila + 1}")
        valores = [
            leer_numero(f"  Coeficiente de x{columna + 1}: ")
            for columna in range(variables)
        ]
        valores.append(leer_numero("  Término independiente: "))
        matriz.append(valores)
    return matriz


def resolver_interactivamente():
    print("=" * 64)
    print("AXION — Calculadora de Álgebra Lineal")
    print("Eliminación por filas con aritmética racional exacta")
    print("=" * 64)
    matriz = solicitar_sistema()
    entrada_metodo = input(
        "\nMétodo [A=Automático, G=Gauss, J=Gauss-Jordan] (A): "
    ).strip().lower()
    metodo = {"g": "gauss", "j": "gauss-jordan"}.get(entrada_metodo, "automatico")
    resultado = resolver_sistema(matriz, metodo)
    print("\nSISTEMA ORIGINAL")
    print(texto_ecuaciones(resultado.original))
    print("\nPROCEDIMIENTO")
    for paso in resultado.pasos:
        print(f"\nPaso {paso.indice:02d} — {paso.titulo}")
        print(f"Objetivo: {paso.objetivo}")
        print(f"Operación: {paso.notacion_operacion}")
        print(paso.explicacion_breve)
        print(texto_matriz(paso.matriz_despues))
    print("\nRESULTADO")
    print(f"Clasificación: {resultado.clasificacion}")
    print(f"Rango(A) = {resultado.rango_a}")
    print(f"Rango([A|b]) = {resultado.rango_aumentada}")
    print("Pivotes:", resultado.posiciones_pivote or "ninguno")
    print("Variables básicas:", [columna + 1 for columna in resultado.variables_basicas] or "ninguna")
    print("Variables libres:", [columna + 1 for columna in resultado.variables_libres] or "ninguna")
    if resultado.solucion_unica is not None:
        for indice, valor in enumerate(resultado.solucion_unica):
            print(f"x{indice + 1} = {formatear_numero(valor)}")
    elif resultado.clasificacion == "infinitas":
        print("\n".join(lineas_parametricas(resultado)))
    else:
        print(f"Contradicción: 0 = {formatear_numero(resultado.fila_contradiccion[-1])}")
    print("\nCONCLUSIÓN")
    print(resultado.conclusion)


def iniciar_interfaz_visual():
    lanzar_aplicacion()


if __name__ == "__main__":
    if "--cli" in sys.argv:
        resolver_interactivamente()
    else:
        iniciar_interfaz_visual()
